<?php
$tripData = [];

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $trip_by_id = $trip_info->GetAllTripAndBusByTripId($id);

    if ($trip_by_id) {
        $tripData = $trip_by_id->fetch_assoc();
    }
}

$sms = '';

if (isset($_POST['btn'])) {
    // Handle form submission and database update here
    $update_trip = updateTripById($_POST, $id);

    if ($update_trip) {
        $sms = '<div class="alert alert-success alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>' . $update_trip . '</strong> </div>';
    } else {
        $sms = '<div class="alert alert-danger alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Error: Trip information update failed.</strong></div>';
    }
}

if (isset($_POST['delete'])) {
    $trip_id_to_delete = $_POST['trip_id'];
    $delete_result = $trip_info->DeleteTripById($trip_id_to_delete); // Corrected function name

    if ($delete_result) {
        $sms = '<div class="alert alert-success alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Trip deleted successfully.</strong></div>';
    } else {
        $sms = '<div class="alert alert-danger alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Error: Trip deletion failed.</strong></div>';
    }
}

// ...


// Fetch all trip data for display
$all_trip_result = $trip_info->GetAllTripAndBus();
$all_trip = [];

while ($row = $all_trip_result->fetch_assoc()) {
    $all_trip[] = $row;
}
?>

<script type="text/javascript">
    function confirmation() {
        return confirm('Are you sure you want to do this?');
    }
</script>

<section class="content-header">
    <h1>Manage Trip Information</h1>
</section>

<!-- Main content -->
<section class="content">
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title">Trip Information Table</h3>
            <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                    <i class="fa fa-minus"></i>
                </button>
                <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                    <i class="fa fa-times"></i>
                </button>
            </div>
        </div>

        <?php if (isset($sms)) {
            echo $sms;
        } ?>

        <div class="box-body">
            <div class="col-md-12">
                <div class="box">
                    <div class="box-header with-border" style="text-align:center;">
                        <h3 class="box-title" style="font-weight: bolder;">All Trip Information</h3>
                    </div>

                    <div class="box-body">
                        <table class="table table-bordered">
                            <tr>
                                <th style="width: 10px">Sl.</th>
                                <th>Bus No</th>
                                <th>From City</th>
                                <th>To City</th>
                                <th>Fare</th>
                                <th>Departure Time</th>
                                <th>Arrival Time</th>
                                <!-- Only Admin can access this section -->
                                <?php if (Session::get('admin_login')) { ?>
                                    <th>Action</th>
                                <?php } ?>
                            </tr>

                            <?php
                            $i = 1;
                            foreach ($all_trip as $trip) {
                            ?>
                                <form method="post" action="">
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $trip['bus_no']; ?></td>
                                        <td><?php echo $trip['from_city']; ?></td>
                                        <td><?php echo $trip['to_city']; ?></td>
                                        <td><?php echo $trip['fare']; ?></td>
                                        <td><?php echo $trip['departure_time']; ?></td>
                                        <td><?php echo $trip['arrival_time']; ?></td>
                                        <!-- Only Admin can access this section -->
                                        <?php if (Session::get('admin_login')) { ?>
                                            <td class="center">
                                                <button class="btn btn-xs btn-danger" type="submit" name="delete" onclick="return confirm('Are you sure to delete?')">
                                                    <i class="fa fa-fw fa-trash"></i>Delete
                                                </button>
                                                <input type="hidden" name="trip_id" value="<?php echo $trip['trip_id']; ?>">
                                                <a class="btn btn-xs btn-info" href="dashboard.php?page=update_trip&id=<?php echo $trip['trip_id']; ?>">
                                                    <i class="fa fa-fw fa-edit"></i>Edit
                                                </a>
                                            </td>
                                        <?php } ?>
                                    </tr>
                                </form>
                            <?php
                                $i++;
                            }
                            ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
</body>
</html>
