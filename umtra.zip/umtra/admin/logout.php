<?php 
	require_once "../Session.php";
  	Session::init();
  	Session::destroy();
  	
 ?>
<


  
 
 