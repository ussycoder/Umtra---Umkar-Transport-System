<?php

  // $AllCity = $city->GetAllCity();
  // $AllCity = $AllCity->fetch_array(MYSQLI_ASSOC);

	// if(isset($_POST['delete'])){
  //   $id = $_POST['city_id'];
  //   $delet_city = $city->DeleteCityById($id);
  //   $sms = '<div class="alert alert-success alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>'.$delet_city.'</strong> </div>';
  // }

// $AllCity = $city->GetAllCity();
// $AllCity = $AllCity->fetch_array(MYSQLI_ASSOC);

// if (isset($_POST['delete'])) {
//     $id = $_POST['city_id'];

//     // Ensure $AllCity is an array and that 'city_id' exists in it
//     if (is_array($AllCity) && isset($AllCity['city_id'])) {
//         $delet_city = $city->DeleteCityById($id);
//         $sms = '<div class="alert alert-success alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>' . $delet_city . '</strong> </div>';
//     } else {
//         // Handle the case where $AllCity is not an array or 'city_id' doesn't exist
//         $sms = '<div class="alert alert-danger alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Error: City data not available.</strong></div>';
//     }
// }

// Initialize SMS variable
$sms = '';

// Check if the delete button is clicked
if (isset($_POST['delete'])) {
    // Get the city_id from the form
    $id = $_POST['city_id'];

    // Attempt to delete the city by its ID
    $delet_city = $city->DeleteCityById($id);

    // Check if the deletion was successful
    if ($delet_city) {
        $sms = '<div class="alert alert-success alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>' . $delet_city . '</strong> </div>';
    } else {
        // Handle the case where the deletion failed
        $sms = '<div class="alert alert-danger alert-dismissable"><a ref="#" class="close" data-dismiss="alert" aria-label="close">&times;</a><strong>Error: City deletion failed.</strong></div>';
    }
}

// Fetch all city information
$AllCity = $city->GetAllCity();
?>

<?php if (!empty($sms)) echo $sms; ?>

    <section class="content-header">
      <h1>Manage City Information</h1>
	  
    </section>

    <!-- Main content -->
    <section class="content">

      <!-- Default box -->
      <div class="box">
        <div class="box-header with-border">
          <h3 class="box-title">City Information Table</h3>

          <div class="box-tools pull-right">
            <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip"
                    title="Collapse">
              <i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
              <i class="fa fa-times"></i></button>
          </div>
        </div>
		
		<?php if(isset($sms)){echo $sms;} ?>
		
        <div class="box-body">
		
          <div class="col-md-12">
          <div class="box">
            <div class="box-header with-border"style="text-align:center;">
              <h3 class="box-title" style="font-weight: bolder;" >All City Inforamtion</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tr >
                  <th>Sl.</th>
                  <th>City Name</th>
                  <th>Action</th>
                </tr>
				
		  <?php
        $i=1;
         foreach($AllCity as $value)
      {
      ?>
                		 
			<form  method="post" action="">
			    <tr>
              <td><?php echo $i;?></td>
              <td>
    <?php
    if (is_array($value) && isset($value['city_name'])) {
        echo $value['city_name'];
    } else {
        echo "City name not available";
    }
    ?>
</td>
              
              <td class="center">
                <button class="btn btn-xs btn-danger" type="submit" name="delete" onclick="return confirm('Are you sure to delete?')">
                  <i class="fa fa-fw fa-trash"></i>Delete</a>
                </button>
                <input type="hidden" name="city_id" value="<?php echo $value['city_id']; ?>">            
                <a class="btn btn-xs btn-info" href="dashboard.php?page=update_city&id=<?php echo $value['city_id']; ?>&name=<?php echo $value['city_name']; ?>">
                  <i class="fa fa-fw fa-edit"></i>Edit</a>
                </a>
              </td>            
          </tr>
					
				</form>
				<?php
			    $i++;
				}
				?>
     
              </table>
            </div>
            
        </div>
        </div>
       
      </div>
      <!-- /.box -->

    </section>
    <!-- /.content -->
  </div>
