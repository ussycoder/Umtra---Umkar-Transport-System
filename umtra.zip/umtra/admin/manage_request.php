<?php
$AllBooking = $booking_info->GetAllBookingWithUser();

if ($AllBooking) {
    $i = 1;
?>
    <section class="content-header">
        <h1>Manage Booking Requests</h1>
    </section>

    <section class="content">
        <div class="box">
            <div class="box-header with-border" style="text-align:center;">
                <h3 class="box-title" style="font-weight: bolder;">All Booking Requests</h3>
            </div>
            <div class="box-body">
                <table class="table table-bordered">
                    <tr>
                        <th>Sl.</th>
                        <th>PNR No</th>
                        <th>Passenger Name</th>
                        <th>Email</th>
                        <th>Contact No</th>
                        <th>Booking Date</th>
                        <th>Request Status</th>
                        <th>Action</th>
                    </tr>

                    <?php
                    while ($data = $AllBooking->fetch_array(MYSQLI_ASSOC)) {
                        if (isset($data['pnr_no'])) {
                            $bookingStatus = $data['booking_status'];
                            $statusText = '';
                            $statusClass = '';
                            if ($bookingStatus == 1) {
                                $statusText = 'approved';
                                $statusClass = 'btn-success';
                            } elseif ($bookingStatus == 0) {
                                $statusText = 'pending';
                                $statusClass = 'btn-warning';
                            } elseif ($bookingStatus == 2) {
                                $statusText = 'cancelled';
                                $statusClass = 'btn-danger';
                            }
                    ?>
                            <tr>
                                <td><h5><?php echo $i; ?></h5></td>
                                <td><h5><?php echo $data['pnr_no']; ?></h5></td>
                                <td><h5><?php echo $data['name']; ?></h5></td>
                                <td><h5><?php echo $data['email']; ?></h5></td>
                                <td><h5><?php echo $data['mobile']; ?></h5></td>
                                <td><h5><?php echo $data['booking_date']; ?></h5></td>
                                <td>
                                    <a class="btn btn-xs <?php echo $statusClass; ?>">
                                        <span class="glyphicon glyphicon-check"></span> <?php echo $statusText; ?>
                                    </a>
                                </td>
                                <td>
                                    <a href="dashboard.php?page=view_request&id=<?php echo $data['booking_id']; ?>" class="btn btn-xs btn-info">
                                        <i class="fa fa-clock-o"></i> View details
                                    </a>
                                </td>
                            </tr>
                    <?php
                            $i++;
                        } else {
                            echo "PNR No not found for this record.";
                        }
                    }
                    ?>
                </table><br />
            </div>
        </div>
    </section>
<?php
} else {
    echo "No records found.";
}
?>
