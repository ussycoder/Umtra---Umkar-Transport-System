<?php

/**
 * Reserved_info class
 */

require_once "Database.php";
require_once "Format.php";
require_once "BaseClass.php";

class Reserved_info extends BaseClass
{
    /**
     * Insert a reserved seat into the database.
     *
     * @param array $data An array containing seat and trip information.
     * @return bool True on success, false on failure.
     */
    public function insertSeat($data)
    {
        // Validate and sanitize input data
        $trip_id = $this->test_input($data['trip_id']);
        $bus_id = $this->test_input($data['bus_id']);
        $passenger_id = $this->test_input($data['passenger_id']);
        $journey_date = $this->test_input($data['journey_date']);
        $seat = $this->test_input($data['seat']);
        $session_id = $this->test_input($data['session_id']);

        $sql = "INSERT INTO tbl_reserved_seat (trip_id, user_id, session_id, bus_id, `date`, seat_no)
                VALUES ('$trip_id', '$passenger_id', '$session_id', '$bus_id', '$journey_date', '$seat')";

        // Execute the SQL query and handle errors
        $result = $this->db->insert($sql);

        return $result;
    }

    /**
     * Delete a reserved seat from the database.
     *
     * @param array $data An array containing seat and trip information.
     * @return bool True on success, false on failure.
     */
    public function deleteSeat($data)
    {
        // Validate and sanitize input data
        $trip_id = $this->test_input($data['trip_id']);
        $passenger_id = $this->test_input($data['passenger_id']);
        $journey_date = $this->test_input($data['journey_date']);
        $seat = $this->test_input($data['seat']);

        $sql = "DELETE FROM tbl_reserved_seat
                WHERE seat_no='$seat' AND trip_id = '$trip_id' AND `date` = '$journey_date' AND user_id='$passenger_id'";

        // Execute the SQL query and handle errors
        $result = $this->db->delete($sql);

        return $result;
    }

    /**
     * Delete all selected seats for a user and trip.
     *
     * @param array $data An array containing trip and user information.
     * @return bool True on success, false on failure.
     */
    public function deleteAllSelectedSeats($data)
    {
        // Validate and sanitize input data
        $trip_id = $this->test_input($data['trip_id']);
        $session_id = $this->test_input($data['session_id']);
        $passenger_id = $this->test_input($data['passenger_id']);
        $journey_date = $this->test_input($data['journey_date']);

        $sql = "DELETE FROM tbl_reserved_seat
                WHERE trip_id = '$trip_id' AND `date` = '$journey_date' AND user_id='$passenger_id'";

        // Execute the SQL query and handle errors
        $result = $this->db->delete($sql);

        return $result;
    }

    /**
     * Sanitize and validate input data.
     *
     * @param mixed $data The input data to sanitize and validate.
     * @return mixed The sanitized and validated data.
     */
    public function test_input($data)
    {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        $data = $this->fm->validation($data);
        $data = mysqli_real_escape_string($this->db->link, $data);

        return $data;
    }
}

?>
